# speedydrop
A template website for delivery businesses
